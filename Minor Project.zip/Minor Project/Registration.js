const form = document.getElementById('registrationForm');
form.addEventListener('submit', (event) => {
  event.preventDefault();

  const fname = document.getElementById('fname').value;
  const lname = document.getElementById('lname').value;
  const email = document.getElementById('email').value;
  const modal= document.getElementById('modal_text');
  

  if (fname === '') {
    modal.textContent = 'Please enter your first name';
  } 

  if (lname === '') {
    modal.textContent = 'Please enter your last name';
  } 


  if (email === '') {
    modal.textContent = 'Please enter your email';
  }

  // Form data is valid, submit it to the server
  form.submit();
});

